import ipaddress
import socket
import select
import time
import httpx

def tcping(ip):
    try:
        # 创建TCP套接字
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setblocking(0)  # 设置非阻塞模式
        
        # 开始计时
        start_time = time.time()
        
        # 尝试连接
        try:
            sock.connect((ip, 443))
        except BlockingIOError:
            pass
        
        # 使用select等待连接，超时时间1秒
        ready = select.select([], [sock], [], 0.1)
        if ready[1]:
            # 检查是否真正连接成功
            try:
                sock.getpeername()
                end_time = time.time()
                latency = int((end_time - start_time) * 1000)  # 转换为毫秒
                return latency
            except socket.error:
                pass
    except Exception:
        pass
    finally:
        try:
            sock.close()
        except Exception:
            pass
    return None

def process_ip_ranges():
    import os
    script_dir = os.path.dirname(os.path.abspath(__file__))
    input_file = os.path.join(script_dir, 'eo.txt')
    output_file = os.path.join(script_dir, '100ms.txt')
    
    print(f'输出文件路径: {output_file}')
    with open(output_file, 'w') as f:
        f.write('')  # 清空文件
        f.flush()
    import sys
    sys.stdout.flush()
    
    with open(input_file, 'r') as f:
        ip_ranges = f.read().splitlines()
    
    total_ranges = len(ip_ranges)
    print(f"开始处理 {total_ranges} 个IP段...")
    import sys
    sys.stdout.flush()
    
    with open(output_file, 'a') as out_f:
        for index, ip_range in enumerate(ip_ranges, 1):
            try:
                # 将CIDR表示法转换为IP网络对象
                network = ipaddress.ip_network(ip_range)
                print(f"\n[{index}/{total_ranges}] 正在测试网段: {ip_range}")
                
                # 遍历每个C段的第一个IP
                for third_octet in range(network.network_address.packed[2], network.broadcast_address.packed[2] + 1):
                    ip = f"{str(network.network_address).rsplit('.', 2)[0]}.{third_octet}.1"
                    latency = tcping(ip)
                    
                    if latency is None:
                        print(f"{ip} 超时")
                        sys.stdout.flush()
                    elif latency <= 200:
                        # 如果延迟合格，进行httpx请求
                        try:
                            with httpx.Client(verify=False, timeout=5) as client:
                                response = client.get(f"https://{ip}", follow_redirects=True)
                                if response.status_code == 418:
                                    print(ip)
                                    sys.stdout.flush()
                                    out_f.write(f"{ip}\n")
                                    out_f.flush()
                        except Exception as e:
                            print(f"{ip} {latency}ms [HTTP请求失败]")
                            sys.stdout.flush()
                    else:
                        print(f"{ip} {latency}ms")
                        sys.stdout.flush()
                        
            except Exception as e:
                print(f"处理 {ip_range} 时出错: {e}")
                continue
                        
            except Exception as e:
                print(f"Error processing {ip_range}: {e}")
                continue

if __name__ == '__main__':
    process_ip_ranges()