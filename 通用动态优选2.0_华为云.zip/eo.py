import subprocess
import ipaddress
from pathlib import Path
import concurrent.futures

# ===================== 配置区域 =====================
INPUT_FILE = "eo.txt"
OUTPUT_FILE = "yes.txt"
TIMEOUT = 0.5  # 每个请求的超时时间，单位：秒
MAX_WORKERS = 50  # 最大并发数
TARGET_HOST = "eo-r2.afo.im"
# ====================================================

def expand_ips(line):
    """解析IP或CIDR，返回IP列表"""
    try:
        net = ipaddress.ip_network(line.strip(), strict=False)
        return [str(ip) for ip in net.hosts()]
    except ValueError:
        return [line.strip()]  # 单个IP

def check_ip(ip):
    """使用curl尝试绑定IP访问目标站点"""
    curl_cmd = [
        "curl",
        "-s",                     # 静默模式
        "-o", "/dev/null",       # 忽略输出
        "-w", "%{http_code}",    # 输出HTTP状态码
        "--resolve", f"{TARGET_HOST}:443:{ip}",
        "--max-time", str(TIMEOUT),
        f"https://{TARGET_HOST}"
    ]

    try:
        result = subprocess.run(
            curl_cmd,
            capture_output=True,
            text=True,
            timeout=TIMEOUT + 2  # 预留少量时间用于命令处理
        )
        status_code = result.stdout.strip()
        if status_code == "404":
            print(f"[+] {ip} ✅")
            return ip
        else:
            print(f"[-] {ip} ❌ (HTTP {status_code})")
    except subprocess.TimeoutExpired:
        print(f"[!] {ip} ⏰ 超时")
    except Exception as e:
        print(f"[!] {ip} ⚠️ 错误: {e}")
    return None

def main():
    input_path = Path(INPUT_FILE)
    output_path = Path(OUTPUT_FILE)
    output_path.write_text("")  # 清空 yes.txt

    all_ips = []
    for line in input_path.read_text(encoding='utf-8').splitlines():
        if not line.strip():
            continue
        all_ips.extend(expand_ips(line))

    print(f"共加载 {len(all_ips)} 个IP，开始检查...\n")

    valid_ips = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = {executor.submit(check_ip, ip): ip for ip in all_ips}
        for future in concurrent.futures.as_completed(futures):
            result_ip = future.result()
            if result_ip:
                valid_ips.append(result_ip)

    # 写入有效IP
    output_path.write_text("\n".join(valid_ips), encoding='utf-8')
    print(f"\n✅ 检测完成，{len(valid_ips)} 个IP可用，已写入 {OUTPUT_FILE}")

if __name__ == "__main__":
    main()
